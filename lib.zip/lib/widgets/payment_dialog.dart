import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../screens/receipt_screen.dart';
import '../services/voice_service.dart';

class PaymentDialog extends StatefulWidget {
  const PaymentDialog({super.key});

  @override
  State<PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends State<PaymentDialog> {
  final TextEditingController _controller = TextEditingController();
  int _paid = 0;
  String _paymentMethod = 'Cash';

  // ============ HANYA 3 METODE: CASH, QRIS, DEBIT ============
  final List<Map<String, dynamic>> _methods = [
    {
      'name': 'Cash',
      'icon': Icons.payments_outlined,
      'color': const Color(0xFF4CAF50),
      'type': 'cash',
    },
    {
      'name': 'QRIS',
      'icon': Icons.qr_code_2,
      'color': const Color(0xFFE91E63),
      'type': 'qris',
    },
    {
      'name': 'Debit',
      'icon': Icons.credit_card,
      'color': const Color(0xFF2196F3),
      'type': 'card',
    },
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Map<String, dynamic> get _activeMethod =>
      _methods.firstWhere((m) => m['name'] == _paymentMethod);

  String get _activeType => _activeMethod['type'] as String;

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartProvider>();
    final total = cart.totalPrice;
    final currency = NumberFormat.currency(
        locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    final change = _paid - total;
    final primary = Theme.of(context).colorScheme.primary;
    final maxHeight = MediaQuery.of(context).size.height * 0.85;

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      insetPadding: const EdgeInsets.all(16),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: maxHeight, maxWidth: 500),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ============ HEADER ============
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: primary.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(Icons.payment, color: primary, size: 20),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Pembayaran',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // ============ TOTAL BELANJA ============
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [primary, primary.withOpacity(0.8)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Total Belanja',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.85),
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        currency.format(total),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 22,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // ============ PILIH METODE (3 TOMBESAR) ============
                const Text(
                  'Pilih Metode Pembayaran',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                ),
                const SizedBox(height: 10),
                Row(
                  children: _methods.map((m) {
                    final selected = _paymentMethod == m['name'];
                    final isLast = m == _methods.last;
                    return Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(right: isLast ? 0 : 8),
                        child: _MethodTile(
                          name: m['name'],
                          icon: m['icon'],
                          color: m['color'],
                          selected: selected,
                          onTap: () {
                            setState(() {
                              _paymentMethod = m['name'];
                              if (m['type'] == 'cash') {
                                _paid = 0;
                                _controller.text = '';
                              } else {
                                _paid = total;
                                _controller.text = total.toString();
                              }
                            });
                          },
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 18),

                // ============ KONTEN DINAMIS ============
                if (_activeType == 'cash') ...[
                  // ========== CASH ==========
                  TextField(
                    controller: _controller,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Jumlah Dibayar',
                      prefixText: 'Rp ',
                    ),
                    onChanged: (v) =>
                        setState(() => _paid = int.tryParse(v) ?? 0),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _quickChip(total, 'Uang Pas'),
                      _quickChip(20000, 'Rp 20rb'),
                      _quickChip(50000, 'Rp 50rb'),
                      _quickChip(100000, 'Rp 100rb'),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: (change < 0 ? Colors.red : Colors.green)
                          .withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Kembalian',
                            style: TextStyle(fontSize: 13)),
                        Text(
                          currency.format(change < 0 ? 0 : change),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: change < 0
                                ? Colors.red.shade700
                                : Colors.green.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ] else if (_activeType == 'qris') ...[
                  // ========== QRIS ==========
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Column(
                      children: [
                        Icon(Icons.qr_code_2,
                            size: 110, color: Colors.grey.shade700),
                        const SizedBox(height: 8),
                        Text(
                          'Scan QRIS untuk membayar',
                          style: TextStyle(
                              color: Colors.grey.shade700, fontSize: 12),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Semua e-wallet & mobile banking',
                          style: TextStyle(
                              color: Colors.grey.shade500, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                ] else ...[
                  // ========== DEBIT ==========
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: _activeMethod['color'].withOpacity(0.08),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                          color: _activeMethod['color'].withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        Icon(Icons.credit_card,
                            size: 90, color: _activeMethod['color']),
                        const SizedBox(height: 10),
                        Text(
                          'Gesek / Tap kartu Debit di mesin EDC',
                          style: TextStyle(
                              color: _activeMethod['color'],
                              fontSize: 12,
                              fontWeight: FontWeight.w700),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Pastikan nominal di EDC: ${currency.format(total)}',
                          style: TextStyle(
                              color: Colors.grey.shade600, fontSize: 11),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 20),

                // ============ TOMBOL AKSI ============
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text('Batal'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      flex: 2,
                      child: FilledButton(
                        onPressed: _paid < total
                            ? null
                            : () async {
                                final trx = await cart.checkout(
                                  _paid,
                                  paymentMethod: _paymentMethod,
                                );
                                if (context.mounted) {
                                  // ============ SUARA OTOMATIS ============
                                  if (_activeType == 'qris') {
                                    final formatted =
                                        NumberFormat.currency(
                                      locale: 'id_ID',
                                      symbol: '',
                                      decimalDigits: 0,
                                    ).format(total).trim();
                                    await VoiceService.speak(
                                        'Transaksi berhasil, uang masuk $formatted rupiah via QRIS');
                                  } else if (_activeType == 'card') {
                                    final formatted =
                                        NumberFormat.currency(
                                      locale: 'id_ID',
                                      symbol: '',
                                      decimalDigits: 0,
                                    ).format(total).trim();
                                    await VoiceService.speak(
                                        'Transaksi berhasil, kartu Debit $formatted rupiah');
                                  }
                                  Navigator.pop(context);
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          ReceiptScreen(transaction: trx),
                                    ),
                                  );
                                }
                              },
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text('Konfirmasi',
                            style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _quickChip(int amount, String label) {
    return ActionChip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      onPressed: () {
        _controller.text = amount.toString();
        setState(() => _paid = amount);
      },
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(color: Colors.grey.shade300),
      ),
      backgroundColor: Colors.white,
    );
  }
}

// ============ TILE METODE PEMBAYARAN ============
class _MethodTile extends StatelessWidget {
  final String name;
  final IconData icon;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  const _MethodTile({
    required this.name,
    required this.icon,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.12) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? color : Colors.grey.shade300,
            width: selected ? 1.6 : 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: selected ? color : Colors.grey.shade600, size: 26),
            const SizedBox(height: 8),
            Text(
              name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
                color: selected ? color : Colors.grey.shade700,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}