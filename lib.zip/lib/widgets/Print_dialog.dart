import 'package:flutter/material.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import '../models/transaction.dart';
import '../services/print_service.dart';

class PrintDialog extends StatefulWidget {
  final TransactionData transaction;
  const PrintDialog({super.key, required this.transaction});

  @override
  State<PrintDialog> createState() => _PrintDialogState();
}

class _PrintDialogState extends State<PrintDialog> {
  List<BluetoothInfo> _devices = [];
  bool _loading = false;
  bool _printing = false;

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    setState(() => _loading = true);
    try {
      final list = await PrintService.getPairedDevices();
      setState(() => _devices = list);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat printer: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _printBluetooth(String mac) async {
    setState(() => _printing = true);
    try {
      final ok = await PrintService.printViaBluetooth(
        trx: widget.transaction,
        macAddress: mac,
      );
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
                ok ? 'Struk berhasil dicetak' : 'Gagal cetak ke printer'),
            backgroundColor: ok ? Colors.green : Colors.red,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _printing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _printWifi() async {
    Navigator.pop(context);
    try {
      await PrintService.printViaWifi(widget.transaction);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal cetak WiFi: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Row(
        children: [
          Icon(Icons.print, color: Color(0xFFD32F2F)),
          SizedBox(width: 8),
          Text('Pilih Metode Cetak'),
        ],
      ),
      content: SizedBox(
        width: double.maxFinite,
        child: _printing
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 12),
                    Text('Sedang mencetak...'),
                  ],
                ),
              )
            : SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Card(
                      elevation: 0,
                      color: Colors.blue.shade50,
                      child: ListTile(
                        leading: const Icon(Icons.wifi,
                            color: Colors.blue, size: 28),
                        title: const Text('Printer WiFi',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: const Text(
                            'AirPrint / Google Cloud Print / PDF'),
                        trailing:
                            const Icon(Icons.arrow_forward_ios, size: 14),
                        onTap: _printWifi,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text('Printer Bluetooth (Thermal):',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(height: 6),
                    if (_loading)
                      const Padding(
                        padding: EdgeInsets.all(12),
                        child: Center(child: CircularProgressIndicator()),
                      )
                    else if (_devices.isEmpty)
                      Card(
                        elevation: 0,
                        color: Colors.orange.shade50,
                        child: const Padding(
                          padding: EdgeInsets.all(12),
                          child: Text(
                            'Tidak ada printer Bluetooth terpasang.\n'
                            'Silakan pasangkan (pair) printer lewat Pengaturan Bluetooth HP terlebih dahulu.',
                            style: TextStyle(fontSize: 12),
                          ),
                        ),
                      )
                    else
                      ..._devices.map((d) => Card(
                            elevation: 0,
                            color: Colors.grey.shade100,
                            child: ListTile(
                              leading: const Icon(Icons.bluetooth,
                                  color: Colors.blue),
                              title: Text(
                                d.name.isEmpty ? 'Tanpa Nama' : d.name,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600),
                              ),
                              subtitle: Text(d.macAdress,
                                  style: const TextStyle(fontSize: 11)),
                              trailing: const Icon(Icons.print, size: 20),
                              onTap: () => _printBluetooth(d.macAdress),
                            ),
                          )),
                    const SizedBox(height: 8),
                    TextButton.icon(
                      onPressed: _loadDevices,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Muat Ulang Daftar Printer'),
                    ),
                  ],
                ),
              ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Tutup'),
        ),
      ],
    );
  }
}