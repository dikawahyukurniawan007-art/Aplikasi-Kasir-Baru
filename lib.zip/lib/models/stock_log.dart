class StockLog {
  final String id;
  final String productId;
  final String productName;
  final int quantity; // positif = masuk, negatif = keluar
  final String type; // 'in' atau 'out'
  final DateTime date;
  final String note;

  StockLog({
    required this.id,
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.type,
    required this.date,
    required this.note,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'productId': productId,
        'productName': productName,
        'quantity': quantity,
        'type': type,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory StockLog.fromJson(Map<String, dynamic> json) => StockLog(
        id: json['id'] ?? '',
        productId: json['productId'] ?? '',
        productName: json['productName'] ?? '',
        quantity: json['quantity'] ?? 0,
        type: json['type'] ?? 'in',
        date: DateTime.parse(json['date']),
        note: json['note'] ?? '',
      );
}