import 'package:flutter/material.dart';

class Product {
  final String id;
  final String name;
  final int price;
  final Color color;
  final String imageUrl;

  int soldCount;

  /// Total user yang menyukai produk ini
  int likedCount;

  /// Status apakah user ini sudah like atau belum
  bool isLiked;

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.color,
    required this.imageUrl,
    this.soldCount = 0,
    this.likedCount = 0,
    this.isLiked = false,
  });

  /// Format "200+" atau "1.2rb" untuk display yang rapi
  String get soldLabel {
    if (soldCount >= 1000) {
      final k = (soldCount / 1000).toStringAsFixed(1);
      return '${k}rb+';
    } else if (soldCount >= 100) {
      return '${(soldCount ~/ 100) * 100}+';
    } else if (soldCount >= 10) {
      return '${(soldCount ~/ 10) * 10}+';
    } else {
      return '$soldCount';
    }
  }

  String get likedLabel {
    if (likedCount >= 1000) {
      final k = (likedCount / 1000).toStringAsFixed(1);
      return '${k}rb';
    }
    return '$likedCount';
  }
}