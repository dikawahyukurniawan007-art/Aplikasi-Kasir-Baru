import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/stock_log.dart';

class StockStorage {
  static const String _keyStocks = 'stocks_v1';
  static const String _keyLogs = 'stock_logs_v1';
  static const int _maxLogs = 500;

  static Future<void> saveStocks(Map<String, int> stocks) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyStocks, jsonEncode(stocks));
  }

  static Future<Map<String, int>> loadStocks() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyStocks);
    if (raw == null || raw.isEmpty) return {};
    final map = jsonDecode(raw) as Map<String, dynamic>;
    return map.map((key, value) => MapEntry(key, value as int));
  }

  static Future<void> saveLogs(List<StockLog> logs) async {
    final prefs = await SharedPreferences.getInstance();
    final trimmed =
        logs.length > _maxLogs ? logs.sublist(logs.length - _maxLogs) : logs;
    final encoded = trimmed.map((l) => l.toJson()).toList();
    await prefs.setString(_keyLogs, jsonEncode(encoded));
  }

  static Future<List<StockLog>> loadLogs() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyLogs);
    if (raw == null || raw.isEmpty) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    return list
        .map((e) => StockLog.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  static Future<void> clearLogs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyLogs);
  }
}