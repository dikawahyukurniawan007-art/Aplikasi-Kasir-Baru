import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:intl/intl.dart';
import '../models/transaction.dart';

class PrinterService {
  static final BlueThermalPrinter _printer = BlueThermalPrinter.instance;

  /// Cek apakah Bluetooth printer tersedia di perangkat.
  static Future<bool> get isAvailable async {
    final available = await _printer.isAvailable;
    return available ?? false;
  }

  /// Ambil daftar device Bluetooth yang sudah dipairing.
  static Future<List<BluetoothDevice>> getPairedDevices() async {
    final devices = await _printer.getBondedDevices();
    return devices ?? [];
  }

  /// Cek status koneksi.
  static Future<bool> get isConnected async {
    final connected = await _printer.isConnected;
    return connected ?? false;
  }

  /// Connect ke printer.
  static Future<bool> connect(BluetoothDevice device) async {
    try {
      await _printer.connect(device);
      return true;
    } catch (e) {
      return false;
    }
  }

  /// Disconnect dari printer.
  static Future<void> disconnect() async {
    await _printer.disconnect();
  }

  /// Cetak struk transaksi.
  static Future<void> printReceipt(TransactionData trx) async {
    final currency = NumberFormat.currency(
        locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    final tanggal = DateFormat('dd/MM/yyyy HH:mm').format(trx.date);

    // Header
    await _printer.printNewLine();
    await _printer.printCustom('BAKPAU KASIR', 2, 1); // size=2, align=1 (center)
    await _printer.printCustom('Jl. Contoh No. 123, Jakarta', 1, 1);
    await _printer.printCustom('Telp: 021-12345678', 1, 1);
    await _printer.printNewLine();
    await _printer.printCustom('--------------------------------', 1, 1);
    await _printer.printCustom('No: ${trx.id}', 1, 0);
    await _printer.printCustom('Tgl: $tanggal', 1, 0);
    await _printer.printCustom('--------------------------------', 1, 1);

    // Item list
    for (var item in trx.items) {
      await _printer.printCustom(item.name, 1, 0);
      final line =
          '  ${item.quantity} x ${currency.format(item.price)}';
      final subtotal = currency.format(item.subtotal);
      // Padding manual agar subtotal rata kanan
      final spaces = 32 - line.length - subtotal.length;
      await _printer.printCustom(
        '$line${spaces > 0 ? ' ' * spaces : ''}$subtotal',
        1,
        0,
      );
    }

    await _printer.printCustom('--------------------------------', 1, 1);
    await _printer.printCustom(
        'TOTAL    : ${currency.format(trx.total)}', 1, 0);
    await _printer.printCustom(
        'BAYAR    : ${currency.format(trx.paid)}', 1, 0);
    await _printer.printCustom(
        'KEMBALI  : ${currency.format(trx.change)}', 1, 0);
    await _printer.printNewLine();
    await _printer.printCustom('Terima kasih!', 1, 1);
    await _printer.printCustom('~ Bakpau Kasir ~', 1, 1);
    await _printer.printNewLine();
    await _printer.printNewLine();
    await _printer.printNewLine();

    // Potong kertas (kalau didukung)
    await _printer.paperCut();
  }

  /// Test print sederhana.
  static Future<void> testPrint() async {
    await _printer.printNewLine();
    await _printer.printCustom('TEST PRINT BERHASIL', 2, 1);
    await _printer.printNewLine();
    await _printer.printNewLine();
  }
}