import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/transaction.dart';

class ReceiptPdfService {
  static Future<Uint8List> buildReceipt(TransactionData trx) async {
    final pdf = pw.Document();
    final currency = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    );
    final tanggal = DateFormat('dd/MM/yyyy HH:mm').format(trx.date);

    const pageFormat = PdfPageFormat(
      58 * 2.83,
      double.infinity,
      marginAll: 4,
    );

    pdf.addPage(
      pw.Page(
        pageFormat: pageFormat,
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Center(
                child: pw.Column(
                  children: [
                    pw.Text('BAKPAU KASIR',
                        style: pw.TextStyle(
                            fontSize: 12,
                            fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 2),
                    pw.Text('Jl. Bakpau No. 1, Indonesia',
                        style: const pw.TextStyle(fontSize: 7)),
                    pw.Text('Telp: 0812-3456-7890',
                        style: const pw.TextStyle(fontSize: 7)),
                  ],
                ),
              ),
              pw.SizedBox(height: 6),
              pw.Divider(thickness: 0.5),
              pw.Text('No   : ${trx.id}',
                  style: const pw.TextStyle(fontSize: 7)),
              pw.Text('Tgl  : $tanggal',
                  style: const pw.TextStyle(fontSize: 7)),
              pw.Divider(thickness: 0.5),
              ...trx.items.map((item) => pw.Padding(
                    padding: const pw.EdgeInsets.symmetric(vertical: 1),
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(item.name,
                            style: pw.TextStyle(
                                fontSize: 8,
                                fontWeight: pw.FontWeight.bold)),
                        pw.Row(
                          mainAxisAlignment:
                              pw.MainAxisAlignment.spaceBetween,
                          children: [
                            pw.Text(
                                '${item.quantity} x ${currency.format(item.price)}',
                                style: const pw.TextStyle(fontSize: 7)),
                            pw.Text(currency.format(item.subtotal),
                                style: const pw.TextStyle(fontSize: 7)),
                          ],
                        ),
                      ],
                    ),
                  )),
              pw.Divider(thickness: 0.5),
              _row('Total', currency.format(trx.total), bold: true),
              _row('Bayar', currency.format(trx.paid)),
              _row('Kembali', currency.format(trx.change)),
              pw.Divider(thickness: 0.5),
              pw.SizedBox(height: 4),
              pw.Center(
                child: pw.Text('Terima kasih sudah membeli\nbakpau kami!',
                    textAlign: pw.TextAlign.center,
                    style: const pw.TextStyle(fontSize: 7)),
              ),
              pw.SizedBox(height: 4),
              pw.Center(
                child: pw.Text('-- Selamat Menikmati --',
                    style: const pw.TextStyle(fontSize: 6)),
              ),
            ],
          );
        },
      ),
    );

    return pdf.save();
  }

  static pw.Widget _row(String label, String value, {bool bold = false}) {
    final style = pw.TextStyle(
      fontSize: 8,
      fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
    );
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 1),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [pw.Text(label, style: style), pw.Text(value, style: style)],
      ),
    );
  }
}