import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../providers/auth_provider.dart';
import 'periodic_detail_screen.dart';
import 'product_stock_detail_screen.dart';
import 'login_screen.dart'; // <--- Import LoginScreen untuk logout

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final auth = context.read<AuthProvider>();
    final currency = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    final primary = Theme.of(context).colorScheme.primary;

    // PopScope mencegah tombol back fisik / swipe gesture keluar dari halaman ini
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F5F2),
        appBar: AppBar(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          title: const Text('Dashboard Admin', style: TextStyle(fontWeight: FontWeight.bold)),
          elevation: 0,
          automaticallyImplyLeading: false, // <--- INI MENGHILANGKAN TOMBOL BACK
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Logout',
              onPressed: () {
                // 1. Logout dari state auth
                auth.logout();
                // 2. Kembali ke LoginScreen dan HAPUS semua riwayat navigasi
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              },
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ================= RINGKASAN HARIAN (BESAR) =================
            _SectionTitle(title: 'Ringkasan Hari Ini', icon: Icons.today),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PeriodicDetailScreen(period: ReportPeriod.daily)),
              ),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primary, primary.withOpacity(0.8)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(color: primary.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 6)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Icon(Icons.payments_outlined, color: Colors.white, size: 30),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20)),
                          child: Text('${cart.dailyTransactionCount} Transaksi', style: const TextStyle(color: Colors.white, fontSize: 12)),
                        )
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text('Pendapatan Hari Ini', style: TextStyle(color: Colors.white70, fontSize: 14)),
                    Text(currency.format(cart.dailyRevenue), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Row(
                      children: [
                        Text('Lihat Detail Per Item', style: TextStyle(color: Colors.white, fontSize: 12)),
                        SizedBox(width: 4),
                        Icon(Icons.arrow_forward_ios, color: Colors.white, size: 10),
                      ],
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // ================= REKAP PERIODE (HARIAN, MINGGUAN, BULANAN) =================
            _SectionTitle(title: 'Rekap Periode', icon: Icons.calendar_month),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _PeriodCard(
                    title: 'Harian',
                    value: currency.format(cart.dailyRevenue),
                    icon: Icons.today,
                    color: Colors.blue.shade600,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const PeriodicDetailScreen(period: ReportPeriod.daily)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _PeriodCard(
                    title: 'Mingguan',
                    value: currency.format(cart.weeklyRevenue),
                    icon: Icons.date_range,
                    color: Colors.indigo.shade400,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const PeriodicDetailScreen(period: ReportPeriod.weekly)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _PeriodCard(
                    title: 'Bulanan',
                    value: currency.format(cart.monthlyRevenue),
                    icon: Icons.calendar_today,
                    color: Colors.purple.shade400,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const PeriodicDetailScreen(period: ReportPeriod.monthly)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                const Expanded(child: SizedBox()), // Kosong untuk keseimbangan grid
              ],
            ),
            const SizedBox(height: 24),

            // ================= MANAJEMEN STOK =================
            _SectionTitle(title: 'Manajemen Stok', icon: Icons.inventory_2),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4)),
                ],
              ),
              child: Column(
                children: cart.products.asMap().entries.map((e) {
                  final p = e.value;
                  final stock = cart.getStock(p.id);
                  final isLast = e.key == cart.products.length - 1;
                  return Column(
                    children: [
                      ListTile(
                        leading: Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: p.color.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            p.name.isNotEmpty ? p.name[0].toUpperCase() : '?',
                            style: TextStyle(color: p.color, fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                        ),
                        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text(
                          'Stok: $stock',
                          style: TextStyle(
                            color: stock <= 5 ? Colors.red.shade600 : Colors.grey.shade600,
                            fontSize: 12,
                            fontWeight: stock <= 5 ? FontWeight.w700 : FontWeight.normal,
                          ),
                        ),
                        trailing: Container(
                          decoration: BoxDecoration(
                            color: primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: IconButton(
                            icon: Icon(Icons.add, color: primary, size: 18),
                            onPressed: () => _showAddStockDialog(context, p.id, p.name),
                          ),
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => ProductStockDetailScreen(productId: p.id)),
                        ),
                      ),
                      if (!isLast) const Divider(height: 1, indent: 70),
                    ],
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),

            // ================= LOG STOK TERAKHIR =================
            _SectionTitle(title: 'Log Stok Terakhir', icon: Icons.history),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4)),
                ],
              ),
              child: cart.stockLogs.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(child: Text('Belum ada log stok', style: TextStyle(color: Colors.grey))),
                    )
                  : Column(
                      children: cart.stockLogs.take(10).toList().asMap().entries.map((e) {
                        final log = e.value;
                        final isIn = log.quantity > 0;
                        final isLast = e.key == cart.stockLogs.take(10).length - 1;
                        return Column(
                          children: [
                            ListTile(
                              dense: true,
                              leading: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: isIn ? Colors.green.withOpacity(0.12) : Colors.red.withOpacity(0.12),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  isIn ? Icons.arrow_downward : Icons.arrow_upward,
                                  size: 14,
                                  color: isIn ? Colors.green : Colors.red,
                                ),
                              ),
                              title: Text(
                                '${log.productName}  ${isIn ? '+' : ''}${log.quantity}',
                                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                              ),
                              subtitle: Text(
                                '${DateFormat('dd/MM/yyyy HH:mm').format(log.date)} · ${log.note}',
                                style: const TextStyle(fontSize: 11),
                              ),
                            ),
                            if (!isLast) const Divider(height: 1, indent: 60),
                          ],
                        );
                      }).toList(),
                    ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _showAddStockDialog(BuildContext context, String productId, String productName) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Tambah Stok $productName', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Jumlah', hintText: 'Contoh: 20'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          FilledButton(
            onPressed: () {
              final qty = int.tryParse(controller.text) ?? 0;
              if (qty > 0) {
                context.read<CartProvider>().addStock(productId, qty, 'Tambah stok manual');
              }
              Navigator.pop(ctx);
            },
            child: const Text('Tambah'),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionTitle({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Color(0xFF2B2B2B)),
        ),
      ],
    );
  }
}

class _PeriodCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _PeriodCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 3)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(height: 12),
            Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 14)),
          ],
        ),
      ),
    );
  }
}