import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';

class ProductStockDetailScreen extends StatelessWidget {
  final String productId;
  const ProductStockDetailScreen({super.key, required this.productId});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final product = cart.products.firstWhere((p) => p.id == productId);
    final logs = cart.getStockLogsForProduct(productId);
    final dateFormat = DateFormat('dd MMM yyyy, HH:mm');

    return Scaffold(
      appBar: AppBar(
        title: Text('Riwayat Stok: ${product.name}'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            color: product.color.withOpacity(0.1),
            child: Column(
              children: [
                Text('Sisa Stok Saat Ini', style: TextStyle(color: Colors.grey.shade700)),
                const SizedBox(height: 8),
                Text('${cart.getStock(productId)}', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: product.color)),
              ],
            ),
          ),
          Expanded(
            child: logs.isEmpty
                ? const Center(child: Text('Belum ada riwayat stok', style: TextStyle(color: Colors.grey)))
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: logs.length,
                    separatorBuilder: (_, __) => const Divider(),
                    itemBuilder: (context, index) {
                      final log = logs[index];
                      final isIn = log.quantity > 0;
                      return ListTile(
                        leading: Icon(
                          isIn ? Icons.arrow_downward : Icons.arrow_upward,
                          color: isIn ? Colors.green : Colors.red,
                        ),
                        title: Text(log.note, style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text(dateFormat.format(log.date)),
                        trailing: Text(
                          '${isIn ? '+' : ''}${log.quantity}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: isIn ? Colors.green : Colors.red,
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}