import 'package:flutter/material.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/printer_service.dart';

class PrinterSetupScreen extends StatefulWidget {
  const PrinterSetupScreen({super.key});

  @override
  State<PrinterSetupScreen> createState() => _PrinterSetupScreenState();
}

class _PrinterSetupScreenState extends State<PrinterSetupScreen> {
  List<BluetoothDevice> _devices = [];
  BluetoothDevice? _selected;
  bool _connecting = false;
  String _status = 'Belum terhubung';

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    final devices = await PrinterService.getPairedDevices();
    setState(() => _devices = devices);
  }

  Future<void> _connect() async {
    if (_selected == null) return;
    setState(() {
      _connecting = true;
      _status = 'Menghubungkan...';
    });
    final ok = await PrinterService.connect(_selected!);
    if (ok) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('printer_address', _selected!.address ?? '');
      await prefs.setString('printer_name', _selected!.name ?? '');
      setState(() => _status = '✅ Terhubung: ${_selected!.name}');
    } else {
      setState(() => _status = '❌ Gagal terhubung');
    }
    setState(() => _connecting = false);
  }

  Future<void> _testPrint() async {
    await PrinterService.testPrint();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Perintah test print terkirim')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Setup Printer Thermal'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Status Printer',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(_status, style: TextStyle(color: Colors.grey.shade700)),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Pilih Printer yang Sudah Dipairing:',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _devices.isEmpty
                ? const Center(
                    child: Text('Tidak ada device Bluetooth terpairing',
                        style: TextStyle(color: Colors.grey)),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _devices.length,
                    itemBuilder: (context, i) {
                      final d = _devices[i];
                      final isSelected = _selected?.address == d.address;
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? primary.withOpacity(0.1)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isSelected
                                ? primary
                                : Colors.grey.shade200,
                            width: isSelected ? 1.5 : 1,
                          ),
                        ),
                        child: ListTile(
                          leading: Icon(Icons.print,
                              color: isSelected ? primary : Colors.grey),
                          title: Text(d.name ?? 'Unknown'),
                          subtitle: Text(d.address ?? '-'),
                          trailing: isSelected
                              ? Icon(Icons.check_circle, color: primary)
                              : null,
                          onTap: () => setState(() => _selected = d),
                        ),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _loadDevices,
                    child: const Text('Refresh'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: FilledButton(
                    onPressed:
                        _selected == null || _connecting ? null : _connect,
                    child: _connecting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white),
                          )
                        : const Text('Hubungkan'),
                  ),
                ),
              ],
            ),
          ),
          if (_status.contains('✅'))
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _testPrint,
                  icon: const Icon(Icons.receipt),
                  label: const Text('Test Print'),
                ),
              ),
            ),
        ],
      ),
    );
  }
}