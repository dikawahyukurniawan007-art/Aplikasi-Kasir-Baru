import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';

class PeriodicDetailScreen extends StatelessWidget {
  final ReportPeriod period;
  const PeriodicDetailScreen({super.key, required this.period});

  String get _title {
    switch (period) {
      case ReportPeriod.daily:
        return 'Detail Penjualan Harian';
      case ReportPeriod.weekly:
        return 'Detail Penjualan Mingguan';
      case ReportPeriod.monthly:
        return 'Detail Penjualan Bulanan';
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final currency = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    final salesData = cart.getItemSalesForPeriod(period);

    return Scaffold(
      appBar: AppBar(
        title: Text(_title),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: salesData.isEmpty
          ? const Center(
              child: Text(
                'Belum ada penjualan pada periode ini',
                style: TextStyle(color: Colors.grey),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: salesData.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final entry = salesData.entries.elementAt(index);
                final name = entry.key;
                final qty = entry.value['qty'];
                final revenue = entry.value['revenue'];

                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: CircleAvatar(
                    backgroundColor: Colors.brown.shade100,
                    child: Text(
                      '$qty',
                      style: TextStyle(
                        color: Colors.brown.shade800,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  title: Text(
                    name,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text('Terjual: $qty pcs'),
                  trailing: Text(
                    currency.format(revenue),
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
    );
  }
}