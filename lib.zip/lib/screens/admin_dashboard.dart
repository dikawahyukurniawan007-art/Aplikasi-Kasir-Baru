import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../services/cart_provider.dart';
import 'history_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final currency =
        NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFFD32F2F),
          foregroundColor: Colors.white,
          title: const Text('Admin Dashboard',
              style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(
              icon: const Icon(Icons.receipt_long),
              tooltip: 'Riwayat Penjualan',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const HistoryScreen()),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Logout',
              onPressed: () => Navigator.pop(context),
            ),
          ],
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(icon: Icon(Icons.inventory), text: 'Kelola Stok'),
              Tab(icon: Icon(Icons.history), text: 'Log Stok'),
              Tab(icon: Icon(Icons.bar_chart), text: 'Penjualan'),
            ],
          ),
        ),
        body: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              color: const Color(0xFFD32F2F).withOpacity(0.05),
              child: Row(
                children: [
                  Expanded(
                    child: _summaryCard(
                      icon: Icons.receipt,
                      label: 'Transaksi Hari Ini',
                      value: '${cart.todayTransactionCount}',
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _summaryCard(
                      icon: Icons.attach_money,
                      label: 'Pendapatan Hari Ini',
                      value: currency.format(cart.todayRevenue),
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  _StockManagerTab(),
                  _StockLogTab(),
                  _SalesTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 26),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 10, color: Colors.grey.shade600)),
                Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: color)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ==================== TAB 1: KELOLA STOK ====================
// ============================================================

class _StockManagerTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: cart.products.length,
      itemBuilder: (context, index) {
        final product = cart.products[index];
        return _stockTile(context, product);
      },
    );
  }

  Widget _stockTile(BuildContext context, Product product) {
    final isLow = product.stock <= 5;
    final isOut = product.stock <= 0;
    final color = isOut
        ? Colors.red
        : isLow
            ? Colors.orange
            : Colors.green;

    return Card(
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(
                product.imageUrl,
                width: 60,
                height: 60,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  width: 60,
                  height: 60,
                  color: product.color,
                  child: Center(
                    child: Text(product.name[0],
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 22)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      isOut
                          ? 'Stok Habis'
                          : 'Stok: ${product.stock} ${isLow ? "(Rendah)" : ""}',
                      style: TextStyle(
                          color: color,
                          fontSize: 11,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                ElevatedButton.icon(
                  onPressed: () =>
                      _showSendStockDialog(context, product, mode: 'tambah'),
                  icon: const Icon(Icons.add_box, size: 16),
                  label: const Text('Kirim',
                      style: TextStyle(fontSize: 11)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    minimumSize: const Size(0, 30),
                  ),
                ),
                const SizedBox(height: 4),
                OutlinedButton.icon(
                  onPressed: () =>
                      _showSendStockDialog(context, product, mode: 'set'),
                  icon: const Icon(Icons.edit, size: 14),
                  label: const Text('Koreksi',
                      style: TextStyle(fontSize: 11)),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    minimumSize: const Size(0, 30),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showSendStockDialog(
    BuildContext context,
    Product product, {
    required String mode,
  }) {
    final controller = TextEditingController(
      text: mode == 'tambah' ? '10' : product.stock.toString(),
    );
    final noteController = TextEditingController(
      text: mode == 'tambah' ? 'Restock dari supplier' : 'Koreksi stok',
    );

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(mode == 'tambah'
            ? 'Kirim Stok: ${product.name}'
            : 'Koreksi Stok: ${product.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (mode == 'tambah')
              Text(
                'Stok saat ini: ${product.stock}',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText:
                    mode == 'tambah' ? 'Jumlah Tambahan' : 'Stok Baru',
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: noteController,
              decoration: const InputDecoration(
                labelText: 'Catatan',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () async {
              final amount = int.tryParse(controller.text) ?? 0;
              final note = noteController.text;
              if (mode == 'tambah') {
                await context.read<CartProvider>().addStock(
                      productId: product.id,
                      amount: amount,
                      note: note,
                    );
              } else {
                await context.read<CartProvider>().setStock(
                      productId: product.id,
                      newStock: amount,
                      note: note,
                    );
              }
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ===================== TAB 2: LOG STOK ======================
// ============================================================

class _StockLogTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final logs = cart.stockLogs;
    final dateFormat = DateFormat('dd MMM, HH:mm');

    if (logs.isEmpty) {
      return const Center(
        child: Text('Belum ada riwayat perubahan stok',
            style: TextStyle(color: Colors.grey)),
      );
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton.icon(
                onPressed: () => _confirmClear(context, cart),
                icon: const Icon(Icons.delete_sweep,
                    size: 16, color: Colors.red),
                label: const Text('Hapus Semua Log',
                    style: TextStyle(color: Colors.red, fontSize: 12)),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: logs.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final log = logs[index];
              final isAdd = log.change > 0;
              final color = isAdd ? Colors.green : Colors.red;

              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: color.withOpacity(0.15),
                  child: Icon(
                    isAdd ? Icons.add : Icons.remove,
                    color: color,
                    size: 20,
                  ),
                ),
                title: Text(log.productName,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${log.reason} • ${log.note}',
                        style: const TextStyle(fontSize: 11)),
                    Text(dateFormat.format(log.date),
                        style: TextStyle(
                            fontSize: 10, color: Colors.grey.shade600)),
                  ],
                ),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${isAdd ? "+" : ""}${log.change}',
                      style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                    ),
                    Text('→ ${log.stockAfter}',
                        style: const TextStyle(
                            fontSize: 10, color: Colors.grey)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _confirmClear(BuildContext context, CartProvider cart) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Semua Log?'),
        content: const Text(
            'Semua riwayat perubahan stok akan dihapus permanen.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              cart.clearStockLogs();
              Navigator.pop(ctx);
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ================== TAB 3: PENJUALAN ========================
// ============================================================

class _SalesTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final currency =
        NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    final history = cart.history;

    if (history.isEmpty) {
      return const Center(
        child: Text('Belum ada transaksi',
            style: TextStyle(color: Colors.grey)),
      );
    }

    final totalRevenue = history.fold<int>(0, (sum, t) => sum + t.total);
    final totalTrx = history.length;
    final totalItemSold = history.fold<int>(
        0,
        (sum, t) =>
            sum + t.items.fold<int>(0, (s, i) => s + i.quantity));

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              _statRow('Total Transaksi Sesi', '$totalTrx'),
              _statRow('Total Item Terjual', '$totalItemSold'),
              _statRow('Total Pendapatan Sesi', currency.format(totalRevenue)),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView.separated(
            itemCount: history.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final trx = history[index];
              return ListTile(
                leading: const Icon(Icons.receipt, color: Colors.green),
                title: Text(currency.format(trx.total),
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(
                  DateFormat('dd MMM yyyy, HH:mm').format(trx.date),
                  style: const TextStyle(fontSize: 11),
                ),
                trailing: Text('${trx.items.length} varian',
                    style: const TextStyle(fontSize: 11)),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _statRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: const TextStyle(fontSize: 13, color: Colors.black87)),
          Text(value,
              style:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        ],
      ),
    );
  }
}