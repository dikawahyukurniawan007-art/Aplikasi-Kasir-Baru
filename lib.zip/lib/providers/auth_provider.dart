import 'package:flutter/material.dart';

class AuthProvider extends ChangeNotifier {
  bool _isAdminLoggedIn = false;

  bool get isAdminLoggedIn => _isAdminLoggedIn;

  final String _adminEmail = 'admin@bakpau.com';
  final String _adminPassword = 'admin123';

  bool login(String email, String password) {
    if (email == _adminEmail && password == _adminPassword) {
      _isAdminLoggedIn = true;
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _isAdminLoggedIn = false;
    notifyListeners();
  }
}