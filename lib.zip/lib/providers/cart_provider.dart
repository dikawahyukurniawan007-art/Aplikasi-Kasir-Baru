import 'package:flutter/material.dart';
import '../models/product.dart';
import '../models/cart_item.dart';
import '../models/transaction.dart';
import '../models/stock_log.dart';
import '../data/dummy_products.dart';
import '../services/excel_service.dart';

class CartProvider extends ChangeNotifier {
  final List<Product> products = dummyProducts;
  final Map<String, CartItem> _cart = {};
  final List<TransactionData> _history = [];
  final ExcelService _excelService = ExcelService();

  final Map<String, int> _stock = {};
  final List<StockLog> _stockLogs = [];

  CartProvider() {
    for (var p in products) {
      _stock[p.id] = 50;
    }
  }

  List<CartItem> get cartItems => _cart.values.toList();
  List<TransactionData> get history => List.unmodifiable(_history.reversed);
  List<StockLog> get stockLogs => List.unmodifiable(_stockLogs.reversed);

  int get totalItemCount =>
      _cart.values.fold(0, (sum, item) => sum + item.quantity);
  int get totalPrice =>
      _cart.values.fold(0, (sum, item) => sum + item.subtotal);

  int getStock(String productId) => _stock[productId] ?? 0;

  /// Produk terlaris (untuk badge TERLARIS)
  List<Product> get bestSellers {
    final sorted = [...products]..sort((a, b) => b.soldCount.compareTo(a.soldCount));
    return sorted.take(3).toList();
  }

  bool isBestSeller(String productId) =>
      bestSellers.any((p) => p.id == productId);

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  bool _isSameWeek(DateTime date) {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final endOfWeek = startOfWeek.add(const Duration(days: 6));
    return date.isAfter(startOfWeek.subtract(const Duration(seconds: 1))) &&
        date.isBefore(endOfWeek.add(const Duration(days: 1)));
  }

  bool _isSameMonth(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year && date.month == now.month;
  }

  int get dailyRevenue => _history
      .where((t) => _isSameDay(t.date, DateTime.now()))
      .fold(0, (sum, t) => sum + t.total);

  int get weeklyRevenue =>
      _history.where((t) => _isSameWeek(t.date)).fold(0, (sum, t) => sum + t.total);

  int get monthlyRevenue => _history
      .where((t) => _isSameMonth(t.date))
      .fold(0, (sum, t) => sum + t.total);

  int get dailyTransactionCount =>
      _history.where((t) => _isSameDay(t.date, DateTime.now())).length;

  // ============ TOGGLE LIKE ============
  void toggleLike(String productId) {
    final product = products.firstWhere((p) => p.id == productId);
    if (product.isLiked) {
      product.isLiked = false;
      product.likedCount = (product.likedCount - 1).clamp(0, 9999999);
    } else {
      product.isLiked = true;
      product.likedCount += 1;
    }
    notifyListeners();
  }

  void addStock(String productId, int quantity, String note) {
    if (quantity <= 0) return;
    _stock[productId] = (_stock[productId] ?? 0) + quantity;
    final product = products.firstWhere((p) => p.id == productId);
    _stockLogs.add(StockLog(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      productId: productId,
      productName: product.name,
      quantity: quantity,
      type: 'in',
      date: DateTime.now(),
      note: note,
    ));
    notifyListeners();
  }

  void addToCart(Product product) {
    final currentStock = _stock[product.id] ?? 0;
    final currentInCart = _cart[product.id]?.quantity ?? 0;
    if (currentInCart >= currentStock) return;
    if (_cart.containsKey(product.id)) {
      _cart[product.id]!.quantity++;
    } else {
      _cart[product.id] = CartItem(product: product);
    }
    notifyListeners();
  }

  void increment(String productId) {
    final currentStock = _stock[productId] ?? 0;
    final currentInCart = _cart[productId]?.quantity ?? 0;
    if (currentInCart >= currentStock) return;
    _cart[productId]?.quantity++;
    notifyListeners();
  }

  void decrement(String productId) {
    final item = _cart[productId];
    if (item == null) return;
    if (item.quantity <= 1) {
      _cart.remove(productId);
    } else {
      item.quantity--;
    }
    notifyListeners();
  }

  void removeItem(String productId) {
    _cart.remove(productId);
    notifyListeners();
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  Future<TransactionData> checkout(int paid,
      {String paymentMethod = 'Cash'}) async {
    final trx = TransactionData.fromCart(
      cartItems: cartItems,
      paid: paid,
      paymentMethod: paymentMethod,
    );

    for (var item in cartItems) {
      final productId = item.product.id;
      final qty = item.quantity;

      // ============ AUTO INCREMENT SOLD COUNT ============
      final product =
          products.firstWhere((p) => p.id == productId);
      product.soldCount += qty;

      // Kurangi stok
      _stock[productId] = (_stock[productId] ?? 0) - qty;
      _stockLogs.add(StockLog(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        productId: productId,
        productName: item.product.name,
        quantity: -qty,
        type: 'out',
        date: DateTime.now(),
        note: 'Terjual',
      ));
    }

    _history.add(trx);
    clearCart();
    notifyListeners();
    await _excelService.appendTransaction(trx);
    return trx;
  }

  Future<String> exportExcelPath() => _excelService.getFilePath();
  Future<void> shareExcel() => _excelService.shareFile();
}